package com.newcwwg.ui.activity;

import android.os.Bundle;
import com.newcwwg.R;
import com.newcwwg.common.activity.BaseActivity;
import android.widget.Button;
import android.view.View;
import android.widget.Toast;
import android.widget.LinearLayout;
import com.newcwwg.hex.ExportFile;
import androidx.core.*;
import android.Manifest;
import android.content.*;
import android.content.pm.*;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.*;
import android.support.v7.app.*;
import android.support.v7.app.AppCompatActivity;
public class MainActivity extends BaseActivity { 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LinearLayout 一键解密=findViewById(R.id.一键解密);
		一键解密.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {		
					ExportFile FTH = new ExportFile();
					FTH.fileToHex("/storage/emulated/0/Android/test.zip","/storage/emulated/0/Android/test.txt");
				}
			});
    }
	
//	private static final int REQUEST_EXTERNAL_STORAGE = 1;
//    private static String[] PERMISSIONS_STORAGE = {
//		"android.permission.READ_EXTERNAL_STORAGE",
//		"android.permission.WRITE_EXTERNAL_STORAGE" };
//    public static void sqqx(Activity activity){
//        try {
//			//检测是否有写的权限
//            int permission = ActivityCompat.checkSelfPermission(activity,"android.permission.WRITE_EXTERNAL_STORAGE");
//            if (permission != PackageManager.PERMISSION_GRANTED) {
//				// 没有写的权限，去申请写的权限，会弹出对话框
//                ActivityCompat.requestPermissions(activity,PERMISSIONS_STORAGE,REQUEST_EXTERNAL_STORAGE);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
}
